#include <iostream>
#include "2.h"

using namespace std;

void fun()
{
    cout << "fun ho gaya\n";
}

int main()
{
    fun();
    funFrom2();
    return 0;
}