#include "2.h"
#include <iostream>

using namespace std;

void funFrom2()
// definition of function
{
    cout << "fun ho gaya from 2.cpp" << endl;
}