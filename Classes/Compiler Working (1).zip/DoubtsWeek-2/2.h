#ifndef _2_H // agr ye MACRO defined na ho
#define _2_H // to isko define krdo

void funFrom2(); // declaration of function

#endif